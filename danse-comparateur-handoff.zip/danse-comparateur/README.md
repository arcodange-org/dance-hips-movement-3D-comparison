# Danse 3D comparateur — passation (Phase 3)

Application 3D web (three.js) pour aider les apprentis danseurs à reproduire et différencier
visuellement six styles : kizomba, semba, kompa, tarraxinha, suave, zouk brésilien.
Animée par une spec biomécanique chiffrée (voir `SPEC.md`), sans mocap.

## Contenu de ce paquet

- `src/App.jsx` : application complète (React + @react-three/fiber + drei). C'est le code exact
  du canvas Vibe « danse-3d-comparateur », avec `ANATOMY_URL = "/anatomy.glb"`.
- `public/anatomy.glb` : squelette réel bassin→pied (647 Ko), maillages BodyParts3D 99 %
  décimés, quantifiés KHR_mesh_quantization.
- `anatomy_meta.json` : positions articulaires réelles (mètres, repère du canvas).
- `SPEC.md` : spec biomécanique complète des six styles + historique du projet.

## Conventions à respecter (verrouillées, ne pas casser)

- **Hiérarchie glTF** : `Skeleton → Pelvis (HipBone_R/L, Sacrum) ; HipPivot_R/L → Femur →
  KneePivot → Tibia/Fibula/Patella → AnklePivot → Foot_R/L`. Le code anime
  `r.hipR/L, r.kneeR/L, r.footR/L` (pivots) et `r.root` (Skeleton).
- **Métriques** : hauteur de hanche 0,8835 m (`HIP_Y`), inter-hanches 0,168 m,
  hanche→genou 0,440 m, genou→cheville 0,389 m. `HIP_WIDTH = 0,34 m`.
- **Clamp sol obligatoire** : `root.position.y ≥ 0`. Le « niveau bas » d'un style vient
  uniquement de la flexion de genou, jamais d'un plateau sous le sol.
- **Curseur Déplacement** : 0 = sur place, 1 = ±17 cm (une largeur de hanche).
- **Modes** : Solo / Observation hanche (lent, ~32 bpm, buste masqué) / Comparaison /
  Face à face (contacts vert/rouge, retard du suiveur 0–2 temps, isolation ghost).
- **Pieds plats** : les rotations de cheville compensent hanche+genou
  (`footL/R.rotation.x = -(hip.rotation.x + knee.rotation.x) + extra`).

## Attribution obligatoire (licence)

Maillages **BodyParts3D** v4.0, © The Database Center for Life Science (DBCLS),
licence **CC BY-SA 2.1 Japan**. L'attribution doit rester visible dans l'app et dans le README
du dépôt. https://dbarchive.biosciencedbc.jp/en/bodyparts3d/license.html

## Tâches de la Phase 3 (dans l'ordre)

1. `npm create vite@latest` (React + TypeScript optionnel), installer `three @react-three/fiber
   @react-three/drei`, copier `src/App.jsx` et `public/anatomy.glb`. Vérifier que tout rend
   comme le canvas (c'est le critère d'acceptation n° 1).
2. Découpage propre : composants (Rig, ModeSelector, Sliders, InfoCards), config des styles
   dans un module séparé, types.
3. Améliorations prévues, par priorité :
   - IK de pas simple (substitution de poids, pieds qui marchent au lieu de glisser quand
     le curseur Déplacement > 0) ;
   - régénération de l'anatomie à plus haute résolution : BodyParts3D
     `isa_BP3D_4.0_obj_99.zip` (FJ IDs : hanche D FJ3152, G FJ3288, sacrum FJ3393, fémurs
     FJ3365/FJ3259, patellas FJ3381/FJ3275, tibias FJ3387/FJ3282, fibulas FJ3366/FJ3260,
     talus FJ3385/FJ3280, calcaneus FJ3360/FJ3256, naviculaires FJ3308/FJ3307), conversion
     avec `trimesh` ou `gltf-transform` (Draco/meshopt maintenant possibles) ;
   - sauvegarde des réglages (localStorage), export vidéo/GIF d'un cycle pour les cours ;
   - vertèbres lombaires/dorsales pour la vague corporelle du suave et le cambré du zouk.
4. Déploiement GitHub Pages ou Vercel (site statique).
5. Phase 4 (plus tard) : Skill « ajouter un style = paramétrer le rig ».

## Pièges connus

- En-tête GLB : magic, LONGUEUR TOTALE, version (ordre glTF spec).
- Repère BodyParts3D = LPS ; le bake appliqué est `(x, z, -y) × 0,001`, origine au centre
  du bassin. Os droits à x négatif.
- Le GLB embarque déjà la compensation de quantification (node scale/translation) :
  ne pas réimporter puis re-exporter sans vérifier les échelles.
