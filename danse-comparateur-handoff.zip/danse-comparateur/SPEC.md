---
name: danse-styles-biomecanique
description: "Spec biomécanique chiffrée des styles de danse du projet d'apprentissage 3D (kizomba, semba, kompa, tarraxinha, suave, zouk brésilien) et état du projet three.js"
---

# Styles de danse : spec biomécanique et projet 3D

Projet de Gabriel : aider les apprentis danseurs à reproduire et différencier visuellement, en 3D dans le web, les courants kizomba / semba / kompa / tarraxinha / suave / zouk brésilien.

## Cadre d'analyse commun

Le « déhanché » se décompose en 4 leviers : translation latérale du bassin, bascule sagittale (tilt antérieur/postérieur), rotation axiale (yaw), dissociation thoraco-pelvienne. L'ancrage se juge sur 3 paramètres : flexion de genou, roulé de pied (talon → plat → avant-pied), complétude du transfert de poids.

## Spec par style (paramètres pour le rig 3D)

### Kizomba (traditionnelle)
- Bassin neutre : mouvement sous-produit du transfert de poids, pas d'isolation
- Pas courts (une longueur de pied), transferts complets (100 % du poids par pas)
- Réception douce avant-pied → plein pied, pauses longues sur place
- Niveau constant, flexion de genou légère et absorbante (≈ 0,10 rad)
- Bassin : roulis ≈ ±0,045 rad suivant les pas ; déplacement : marche lente
- Urban kiz : cadre plus tendu, arrêts nets, encore moins de mouvement pelvien

### Semba
- Rebond vertical dominant (bounce) par pompage des genoux et chevilles
- Réception sur l'avant-pied (flexion plantaire, pieds « ressort »), pieds quittent le sol
- Déhanché de marche amplifié (inclinaison latérale côté appui), aucune isolation
- Posture dressée/athlétique, déplacements amples, changements de direction nets
- Tempo plus rapide que la kizomba (≈ 130 bpm vs ≈ 90)

### Kompa (konpa haïtien)
- Translation latérale pure du bassin en balancier + inclinaison (pelvic drop) côté appui
- Pattern « pas, rassembler, pas, pause » : pause marquée sur le temps 4 avec micro-balancement (hip check)
- Genoux fléchis en continu (≈ 0,28 rad), niveau bas et constant, aucune élévation
- Pieds glissés (ne quittent pas le sol), plein appui, réception silencieuse
- Épaules et buste quasi immobiles : tout le mouvement visible sous la ceinture
- Tempo 110–130 bpm, accents sur les temps 2 et 4

### Tarraxinha
- Isolation pelvienne volontaire maximale : cercles et « 8 » (tilt + translation + rotation)
- Bassin : roulis ≈ ±0,16 rad, tilt ≈ ±0,14 rad, yaw ≈ ±0,12 rad
- Haut du corps strictement immobile (dissociation thoraco-pelvienne maximale)
- Pieds statiques largeur de bassin, plein appui, pas < longueur du pied, déplacement quasi nul
- Genoux légèrement fléchis en permanence, niveau bas constant
- Guide par contact des hanches

### Suave (kizomba)
- Balancement lent sur place : bassin dessine un « 8 couché » (translation + bascule + rotation, amplitude centimétrique)
- Vague corporelle séquentielle L5 → dorsales → tête (flexion lombaire puis extension thoracique) : pas une isolation, une transmission
- Transferts de poids partiels oscillants (≈ 60/40), pas des transferts complets
- Talons au sol, plein appui, niveau bas constant, aucun rise-and-fall
- Position d'équilibre entre ginga (trop passive) et tarraxinha (trop isolée) ; souvent 2 temps par cycle

### Zouk brésilien
- Déhanché généré par l'amplitude des pas + transfert retardé (« catch » tardif du temps, élasticité)
- Rotation d'ouverture de hanche sur les grandes foulées (yaw ≈ ±0,20 rad)
- Cambré (extension lombaire contrôlée), body waves, contre-balance tête/bassin
- Le plus de variations de niveau des six styles (élévations, descentes, dips)
- Appui avant-pied, pression continue dans le sol, foulées longues
- Zouk antillais (zouk love) : base latérale « 3 temps + pause », petits pas glissés, déhanché balancier, plus proche biomécaniquement du kompa

## Projet 3D « comparateur de styles »

- Phase 1 (faite) : prototype Canvas React avec three.js + @react-three/fiber, rig paramétrique procédural (pas de mocap), animation par courbes f(temps) issues de cette spec, tracé de l'orbite du bassin (le « 8 couché » du suave, les cercles de la tarraxinha, la ligne latérale du kompa sont visibles), comparaison côte à côte, tempo et amplitude réglables.
- Phase 2 (faite) : maillages réels BodyParts3D intégrés au Canvas React « danse-3d-comparateur ». Pipeline Python pur `/home/user/work/danse-anatomy/build.py` : extraction sous-ensemble (os coxaux L/R, sacrum, fémurs, patellas, tibias, fibulas, 26 os/pied fusionnés en 1 maillage par côté ; pieds = 52 os réels), bake LPS→Y-up (x, z, -y) ×0.001, origine au centre du bassin, hiérarchie glTF à pivots (Skeleton→Pelvis→HipPivot→KneePivot→AnklePivot→Foot), quantification KHR_mesh_quantization (positions int16 normalisées + node scale/translation de compensation, normales int8, indices uint16) pour tenir sous la limite Canvas de 1 024 000 octets (GLB 647 Ko, canvas final 894 Ko). Attention : en-tête GLB = magic, LONGUEUR TOTALE, version (bug corrigé). Attribution CC BY-SA 2.1 Japan © DBCLS affichée dans le canvas. Métriques réelles dans anatomy_meta.json : hauteur hanche 0,8835 m, inter-hanches 0,168 m, hanche→genou 440 mm, genou→cheville 389 mm. Fonctions de style du canvas agissent sur les pivots (hipR/L, kneeR/L, footR/L) ; clamp root.position.y ≥ 0 (le niveau bas vient de la flexion de genou, jamais du plateau sous le sol) ; curseur « Déplacement » 0 = sur place, 100 % = ±17 cm (1 largeur de hanche, pieds glissés latéralement sans IK de pas : simplification connue, améliorable) ; buste stylisé semi-transparent toggleable au-dessus du sacrum ; modes Solo/Comparaison/Face à face, contacts vert/rouge, isolation ghost, retard suiveur.
- Phase 3 : migration en vrai projet Vite + three.js via Vibe Code, déploiement GitHub Pages/Vercel (permettra Draco/meshopt, IK de pas, plus de 1 Mo).
- Phase 4 : Skill « ajouter un style = paramétrer le rig ».

### Ressources
- Z-Anatomy (template Blender, models dérivés de BodyParts3D, contient Z-Biomechanics.7z « human biomechanics as a rig ») : https://github.com/Z-Anatomy/Models-of-human-anatomy
- BodyParts3D (maillages OBJ, prendre les versions réduction 99 % : isa_BP3D_4.0_obj_99.zip ≈ 136 Mo, partof_BP3D_4.0_obj_99.zip ≈ 62 Mo) : https://dbarchive.biosciencedbc.jp/en/bodyparts3d/download.html
- Licence : CC BY-SA (attribution + partage à l'identique), page License : https://dbarchive.biosciencedbc.jp/en/bodyparts3d/license.html — compatible projet éducatif ouvert, incompatible produit fermé.
- Règle : ne jamais donner les archives brutes à l'agent ; extraire le sous-ensemble utile puis convertir en GLB compressé (trimesh ou gltf-transform).
