import React, { useRef, useState, useMemo, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, useGLTF } from "@react-three/drei";
import * as THREE from "three";

const TAU = Math.PI * 2;
const S1 = (b) => Math.sin(TAU * b);
const S2 = (b) => Math.sin((TAU * b) / 2);
const S4 = (b) => Math.sin((TAU * b) / 4);
const pos = (x) => Math.max(0, x);
const TRAIL_MAX = 320;

const ANATOMY_URL = "/anatomy.glb";
const HIP_Y = 0.8835;
const HIP_WIDTH = 0.34;

const STYLES = {
  kizomba: {
    label: "Kizomba",
    color: "#2dd4bf",
    bullets: [
      "Bassin neutre : mouvement sous-produit du transfert de poids",
      "Transferts complets (100 % du poids), pas courts d'une longueur de pied",
      "Réception douce avant-pied puis plein pied, pauses longues",
      "Niveau constant, genoux légèrement fléchis et absorbants",
    ],
    apply: (r, b, a) => {
      const s = S2(b);
      r.root.position.y = -0.02 + 0.012 * S1(b) * a;
      r.pelvis.rotation.z = 0.045 * s * a;
      r.pelvis.rotation.y = 0.03 * s * a;
      r.pelvis.rotation.x = 0.02 * S1(b) * a;
      r.hipL.rotation.x = -0.28 * s * a;
      r.hipR.rotation.x = 0.28 * s * a;
      r.kneeL.rotation.x = (0.1 + 0.16 * pos(s)) * a;
      r.kneeR.rotation.x = (0.1 + 0.16 * pos(-s)) * a;
    },
  },
  semba: {
    label: "Semba",
    color: "#fb923c",
    bullets: [
      "Rebond vertical par pompage des genoux et des chevilles",
      "Réception sur l'avant-pied, pieds ressort qui quittent le sol",
      "Buste dressé, déplacements amples et rapides",
      "Déhanché de marche amplifié, aucune isolation",
    ],
    apply: (r, b, a) => {
      const s = S2(b);
      r.root.position.y = (0.05 * Math.abs(S1(b)) - 0.06) * a;
      r.pelvis.rotation.z = 0.09 * s * a;
      r.pelvis.rotation.x = 0.04 * S1(b) * a;
      r.hipL.rotation.x = -0.45 * s * a;
      r.hipR.rotation.x = 0.45 * s * a;
      r.kneeL.rotation.x = (0.15 + 0.35 * pos(s)) * a;
      r.kneeR.rotation.x = (0.15 + 0.35 * pos(-s)) * a;
      r.extraL = 0.25 * pos(S1(b)) * a;
      r.extraR = 0.25 * pos(-S1(b)) * a;
      r.chest.rotation.x = -0.08;
      r.head.rotation.x = -0.04;
    },
  },
  kompa: {
    label: "Kompa",
    color: "#f87171",
    bullets: [
      "Balancier latéral : translation pelvienne pure avec drop côté appui",
      "Pause marquée sur le temps 4 (hip check)",
      "Genoux fléchis en continu, niveau bas et constant",
      "Pieds glissés plein appui, épaules immobiles",
    ],
    apply: (r, b, a) => {
      const w = S4(b);
      const sw = 0.9 * Math.tanh(2.2 * w);
      r.root.position.x = 0.1 * sw * a;
      r.root.position.y = -0.06 * a;
      r.pelvis.position.x = 0.02 * sw * a;
      r.pelvis.rotation.z = 0.1 * sw * a;
      r.pelvis.rotation.y = 0.02 * S2(b) * a;
      r.hipL.rotation.x = -0.05;
      r.hipR.rotation.x = -0.05;
      r.kneeL.rotation.x = (0.28 + 0.1 * pos(w)) * a;
      r.kneeR.rotation.x = (0.28 + 0.1 * pos(-w)) * a;
      r.chest.rotation.z = -0.35 * 0.1 * sw * a;
      if (b % 4 >= 3) r.pelvis.position.x += 0.008 * S1(b) * a;
    },
  },
  tarraxinha: {
    label: "Tarraxinha",
    color: "#c084fc",
    bullets: [
      "Isolation pelvienne maximale : cercles et 8 amples",
      "Haut du corps strictement immobile",
      "Pieds statiques plein appui, déplacement quasi nul",
      "Genoux souples, toute l'énergie dans le bassin",
    ],
    apply: (r, b, a) => {
      r.root.position.y = -0.03;
      r.pelvis.rotation.z = 0.16 * S2(b) * a;
      r.pelvis.rotation.x = 0.14 * Math.sin((TAU * b) / 2 + 1.3) * a;
      r.pelvis.rotation.y = 0.12 * Math.cos((TAU * b) / 2) * a;
      r.pelvis.position.x = 0.015 * S2(b) * a;
      r.pelvis.position.z = 0.012 * Math.cos((TAU * b) / 2) * a;
      r.kneeL.rotation.x = (0.12 + 0.06 * S2(b)) * a;
      r.kneeR.rotation.x = (0.12 - 0.06 * S2(b)) * a;
    },
  },
  suave: {
    label: "Suave",
    color: "#4ade80",
    bullets: [
      "Bassin dessinant un 8 couché, sur place",
      "Vague montante L5 vers dorsales vers tête",
      "Transferts partiels oscillants (60/40), talons au sol",
      "Niveau bas et constant, aucun rise-and-fall",
    ],
    apply: (r, b, a) => {
      r.root.position.y = -0.035;
      r.pelvis.position.x = 0.03 * S2(b) * a;
      r.pelvis.position.z = 0.022 * S4(b) * a;
      r.pelvis.rotation.x = 0.05 * Math.sin((TAU * b) / 4 + 1.57) * a;
      r.pelvis.rotation.z = 0.03 * S2(b) * a;
      r.spine.rotation.x = 0.09 * Math.sin((TAU * b) / 4 - 0.5) * a;
      r.chest.rotation.x = 0.08 * Math.sin((TAU * b) / 4 - 1.1) * a;
      r.head.rotation.x = 0.06 * Math.sin((TAU * b) / 4 - 1.7) * a;
      r.kneeL.rotation.x = (0.14 + 0.1 * S2(b)) * a;
      r.kneeR.rotation.x = (0.14 - 0.1 * S2(b)) * a;
    },
  },
  zouk: {
    label: "Zouk brésilien",
    color: "#38bdf8",
    bullets: [
      "Foulées longues, rotation d'ouverture de hanche",
      "Retard élastique du buste (catch tardif du temps)",
      "Cambré et variations de niveau (rise and fall)",
      "Pression continue dans le sol sur l'avant-pied",
    ],
    apply: (r, b, a) => {
      const s = S2(b);
      r.root.position.y = (-0.03 + 0.045 * S4(b)) * a;
      r.pelvis.rotation.y = 0.2 * s * a;
      r.pelvis.rotation.x = 0.07 * s * a;
      r.pelvis.rotation.z = 0.05 * s * a;
      r.hipL.rotation.x = -0.5 * s * a;
      r.hipR.rotation.x = 0.5 * s * a;
      r.kneeL.rotation.x = (0.12 + 0.3 * pos(s)) * a;
      r.kneeR.rotation.x = (0.12 + 0.3 * pos(-s)) * a;
      r.chest.rotation.y = 0.14 * Math.sin((TAU * b) / 2 - 1.0) * a;
      r.chest.rotation.x = -0.14 * (0.5 + 0.5 * S4(b)) * a;
      r.head.rotation.x = -0.08 * (0.5 + 0.5 * Math.sin((TAU * b) / 4 - 0.8)) * a;
    },
  },
};

function resetRig(r) {
  r.root.position.set(0, 0, 0);
  r.root.rotation.set(0, 0, 0);
  r.pelvis.position.set(0, HIP_Y, 0);
  r.pelvis.rotation.set(0, 0, 0);
  r.spine.rotation.set(0, 0, 0);
  r.chest.rotation.set(0, 0, 0);
  r.head.rotation.set(0, 0, 0);
  r.hipL.rotation.set(0, 0, 0);
  r.hipR.rotation.set(0, 0, 0);
  r.kneeL.rotation.set(0, 0, 0);
  r.kneeR.rotation.set(0, 0, 0);
  r.extraL = 0;
  r.extraR = 0;
}

function makeTrail(color) {
  const geom = new THREE.BufferGeometry();
  geom.setAttribute("position", new THREE.BufferAttribute(new Float32Array(TRAIL_MAX * 3), 3));
  geom.setDrawRange(0, 0);
  const line = new THREE.Line(geom, new THREE.LineBasicMaterial({ color }));
  line.frustumCulled = false;
  return line;
}

const BODY = "#94a3b8";
const BODY_DARK = "#64748b";
const TORSO_OPACITY = 0.22;

function Rig({
  styleKey,
  bpm,
  amp,
  playing,
  offset,
  rotationY = 0,
  ghost = false,
  embrace = false,
  phaseOffset = 0,
  pair = null,
  side = null,
  showContacts = false,
  travel = 0,
  showTorso = true,
}) {
  const r = useRef({}).current;
  const reg = (n) => (el) => { r[n] = el; };
  const t = useRef(0);
  const count = useRef(0);
  const tmp = useMemo(() => new THREE.Vector3(), []);
  const trail = useMemo(() => makeTrail(STYLES[styleKey].color), [styleKey]);
  const lastGhost = useRef(null);
  const { scene } = useGLTF(ANATOMY_URL);
  const skel = useMemo(() => {
    const s = scene.clone(true);
    s.traverse((o) => {
      if (o.isMesh) o.material = o.material.clone();
    });
    return s;
  }, [scene]);
  useEffect(() => {
    skel.traverse((o) => {
      if (o.name) r[o.name] = o;
    });
    r.hipR = r["HipPivot_R"];
    r.hipL = r["HipPivot_L"];
    r.kneeR = r["KneePivot_R"];
    r.kneeL = r["KneePivot_L"];
    r.footR = r["AnklePivot_R"];
    r.footL = r["AnklePivot_L"];
  }, [skel]);
  useEffect(() => {
    count.current = 0;
    trail.geometry.setDrawRange(0, 0);
    t.current = 0;
  }, [styleKey, trail]);
  useEffect(() => {
    if (pair && side) {
      pair.current[side] = { chest: r.contactChest, pelvis: r.contactPelvis };
      return () => {
        pair.current[side] = null;
      };
    }
  }, [pair, side]);

  useFrame((_, delta) => {
    if (!r.root || !r.pelvis || !r.footL) return;
    if (playing) t.current += Math.min(delta, 0.1) * (bpm / 60);
    const b = t.current + phaseOffset;
    resetRig(r);
    STYLES[styleKey].apply(r, b, amp);
    r.root.position.x += travel * (HIP_WIDTH / 2) * Math.tanh(2.2 * S2(b));
    if (r.root.position.y < 0) r.root.position.y = 0;
    r.footL.rotation.x = -(r.hipL.rotation.x + r.kneeL.rotation.x) + r.extraL;
    r.footR.rotation.x = -(r.hipR.rotation.x + r.kneeR.rotation.x) + r.extraR;
    const tx = embrace ? -1.05 : -0.25;
    const tf = embrace ? -0.55 : -0.3;
    if (r.armUL && r.armUR && r.armFL && r.armFR) {
      [r.armUL, r.armUR].forEach((g) => {
        g.rotation.x += (tx - g.rotation.x) * 0.08;
      });
      [r.armFL, r.armFR].forEach((g) => {
        g.rotation.x += (tf - g.rotation.x) * 0.08;
      });
    }
    if (lastGhost.current !== ghost) {
      lastGhost.current = ghost;
      r.root.traverse((o) => {
        if (!o.isMesh || o.userData.part === "anchor") return;
        if (o.userData.part === "torso") {
          o.material.opacity = ghost ? 0.02 : TORSO_OPACITY;
        } else {
          o.material.transparent = ghost;
          o.material.opacity = ghost ? 0.1 : 1;
        }
      });
    }
    if (playing) {
      r.pelvis.getWorldPosition(tmp);
      const attr = trail.geometry.attributes.position;
      if (count.current < TRAIL_MAX) {
        attr.setXYZ(count.current, tmp.x, tmp.y, tmp.z);
        count.current += 1;
      } else {
        attr.array.copyWithin(0, 3);
        attr.setXYZ(TRAIL_MAX - 1, tmp.x, tmp.y, tmp.z);
      }
      attr.needsUpdate = true;
      trail.geometry.setDrawRange(0, count.current);
    }
  });

  return (
    <>
      <group position={offset} rotation={[0, rotationY, 0]}>
        <group ref={reg("root")}>
          <group ref={reg("pelvis")} position={[0, HIP_Y, 0]}>
            <primitive object={skel} />
            <mesh
              ref={reg("contactPelvis")}
              userData={{ part: "anchor" }}
              position={[0, 0, 0.12]}
              visible={showContacts}
            >
              <sphereGeometry args={[0.038, 12, 10]} />
              <meshBasicMaterial color="#64748b" />
            </mesh>
            <group ref={reg("torso")} visible={showTorso}>
              <group ref={reg("spine")} position={[0, 0.08, 0]}>
                <mesh userData={{ part: "torso" }} position={[0, 0.06, 0]}>
                  <cylinderGeometry args={[0.05, 0.055, 0.14, 10]} />
                  <meshStandardMaterial
                    color={BODY_DARK}
                    roughness={0.6}
                    transparent
                    opacity={TORSO_OPACITY}
                  />
                </mesh>
                <group ref={reg("chest")} position={[0, 0.24, 0]}>
                  <mesh userData={{ part: "torso" }}>
                    <boxGeometry args={[0.3, 0.26, 0.18]} />
                    <meshStandardMaterial
                      color={BODY}
                      roughness={0.6}
                      transparent
                      opacity={TORSO_OPACITY}
                    />
                  </mesh>
                  <mesh userData={{ part: "torso" }} position={[-0.19, 0.1, 0]}>
                    <sphereGeometry args={[0.05, 12, 10]} />
                    <meshStandardMaterial
                      color={BODY_DARK}
                      roughness={0.6}
                      transparent
                      opacity={TORSO_OPACITY}
                    />
                  </mesh>
                  <mesh userData={{ part: "torso" }} position={[0.19, 0.1, 0]}>
                    <sphereGeometry args={[0.05, 12, 10]} />
                    <meshStandardMaterial
                      color={BODY_DARK}
                      roughness={0.6}
                      transparent
                      opacity={TORSO_OPACITY}
                    />
                  </mesh>
                  {[-1, 1].map((sxi) => (
                    <group
                      key={sxi}
                      ref={reg(sxi < 0 ? "armUL" : "armUR")}
                      position={[0.19 * sxi, 0.1, 0]}
                      rotation={[0, 0, -0.12 * sxi]}
                    >
                      <mesh userData={{ part: "torso" }} position={[0, -0.13, 0]}>
                        <cylinderGeometry args={[0.034, 0.03, 0.26, 10]} />
                        <meshStandardMaterial
                          color={BODY}
                          roughness={0.6}
                          transparent
                          opacity={TORSO_OPACITY}
                        />
                      </mesh>
                      <group ref={reg(sxi < 0 ? "armFL" : "armFR")} position={[0, -0.26, 0]}>
                        <mesh userData={{ part: "torso" }} position={[0, -0.11, 0]}>
                          <cylinderGeometry args={[0.028, 0.024, 0.22, 10]} />
                          <meshStandardMaterial
                            color={BODY_DARK}
                            roughness={0.6}
                            transparent
                            opacity={TORSO_OPACITY}
                          />
                        </mesh>
                        <mesh userData={{ part: "torso" }} position={[0, -0.24, 0]}>
                          <sphereGeometry args={[0.04, 10, 8]} />
                          <meshStandardMaterial
                            color={STYLES[styleKey].color}
                            roughness={0.5}
                            transparent
                            opacity={TORSO_OPACITY}
                          />
                        </mesh>
                      </group>
                    </group>
                  ))}
                  <mesh
                    ref={reg("contactChest")}
                    userData={{ part: "anchor" }}
                    position={[0, 0, 0.13]}
                    visible={showContacts}
                  >
                    <sphereGeometry args={[0.038, 12, 10]} />
                    <meshBasicMaterial color="#64748b" />
                  </mesh>
                  <group ref={reg("head")} position={[0, 0.28, 0]}>
                    <mesh userData={{ part: "torso" }}>
                      <sphereGeometry args={[0.075, 16, 12]} />
                      <meshStandardMaterial
                        color="#cbd5e1"
                        roughness={0.5}
                        transparent
                        opacity={TORSO_OPACITY}
                      />
                    </mesh>
                  </group>
                </group>
              </group>
            </group>
          </group>
        </group>
      </group>
      <primitive object={trail} />
    </>
  );
}

function ContactViz({ pair }) {
  const lines = useMemo(() => {
    const mk = (color) => {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(6), 3));
      const l = new THREE.Line(
        g,
        new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.6 })
      );
      l.frustumCulled = false;
      return l;
    };
    return { chest: mk("#4ade80"), pelvis: mk("#4ade80") };
  }, []);
  const va = useMemo(() => new THREE.Vector3(), []);
  const vb = useMemo(() => new THREE.Vector3(), []);
  useFrame(() => {
    const L = pair.current.leader;
    const F = pair.current.follower;
    if (!L || !F || !L.chest || !F.chest || !L.pelvis || !F.pelvis) return;
    [
      [L.chest, F.chest, lines.chest],
      [L.pelvis, F.pelvis, lines.pelvis],
    ].forEach(([a, b, line]) => {
      a.getWorldPosition(va);
      b.getWorldPosition(vb);
      const contact = va.distanceTo(vb) < 0.09;
      const col = contact ? "#4ade80" : "#f87171";
      a.material.color.set(col);
      b.material.color.set(col);
      a.scale.setScalar(contact ? 1.3 : 1);
      b.scale.setScalar(contact ? 1.3 : 1);
      const attr = line.geometry.attributes.position;
      attr.setXYZ(0, va.x, va.y, va.z);
      attr.setXYZ(1, vb.x, vb.y, vb.z);
      attr.needsUpdate = true;
      line.material.color.set(contact ? "#4ade80" : "#475569");
      line.material.opacity = contact ? 0.8 : 0.3;
    });
  });
  return (
    <>
      <primitive object={lines.chest} />
      <primitive object={lines.pelvis} />
    </>
  );
}

function GridFloor() {
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.002, 0]}>
        <circleGeometry args={[3.4, 48]} />
        <meshStandardMaterial color="#111c33" roughness={1} />
      </mesh>
      <gridHelper args={[6.8, 34, "#243550", "#1a2740"]} />
    </group>
  );
}

function StylePicker({ label, value, onChange }) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wider text-slate-400 mb-1.5">{label}</div>
      <div className="flex flex-wrap gap-1.5">
        {Object.entries(STYLES).map(([key, st]) => {
          const active = key === value;
          return (
            <button
              key={key}
              onClick={() => onChange(key)}
              className={
                "px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors " +
                (active
                  ? "border-transparent text-slate-950"
                  : "border-slate-700 bg-slate-800/60 text-slate-300 hover:bg-slate-700")
              }
              style={active ? { background: st.color } : undefined}
            >
              {st.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function InfoCard({ styleKey, position }) {
  const st = STYLES[styleKey];
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
      <div className="flex items-center gap-2 mb-2">
        <span className="w-2.5 h-2.5 rounded-full" style={{ background: st.color }} />
        <span className="font-semibold">{st.label}</span>
        <span className="text-[10px] uppercase tracking-wider text-slate-500">{position}</span>
      </div>
      <ul className="space-y-1.5">
        {st.bullets.map((bl, i) => (
          <li key={i} className="text-xs text-slate-300 leading-relaxed flex gap-2">
            <span style={{ color: st.color }}>▸</span>
            <span>{bl}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

const MODES = [
  { key: "solo", label: "Solo (mouvement isolé)" },
  { key: "observe", label: "Observation hanche (lent)" },
  { key: "compare", label: "Comparaison côte à côte" },
  { key: "pair", label: "Face à face (symétrie)" },
];

export default function App() {
  const [mode, setMode] = useState("solo");
  const [styleA, setStyleA] = useState("kizomba");
  const [styleB, setStyleB] = useState("kizomba");
  const [ghostSel, setGhostSel] = useState("none");
  const [playing, setPlaying] = useState(true);
  const [bpm, setBpm] = useState(32);
  const [amp, setAmp] = useState(1);
  const [followDelay, setFollowDelay] = useState(0.5);
  const [showContacts, setShowContacts] = useState(true);
  const [travel, setTravel] = useState(0);
  const [showTorso, setShowTorso] = useState(true);
  const pairRef = useRef({});

  const isPair = mode === "pair";
  const isCompare = mode === "compare";
  const isObserve = mode === "observe";
  const ghostA = (isCompare || isPair) && ghostSel === "B";
  const ghostB = ghostSel === "A";

  const offsetA = isPair ? [-0.14, 0, 0] : isCompare ? [-0.85, 0, 0] : [0, 0, 0];
  const offsetB = isPair ? [0.14, 0, 0] : [0.85, 0, 0];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-6 space-y-4 max-w-6xl mx-auto">
      <div>
        <h1 className="text-xl md:text-2xl font-bold tracking-tight">
          Comparateur 3D des styles de danse
        </h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Anatomie réelle du bassin au pied (BodyParts3D) animée par la spec biomécanique. Le
          curseur « Déplacement » passe du sur place à une amplitude latérale d'une largeur de
          hanche. Le tracé coloré visualise l'orbite du centre du bassin. Mode « Observation
          hanche » : tempo lent (~32 bpm), buste masqué, pour détailler le déhanché temps par temps.
        </p>
      </div>

      <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4 space-y-4">
        <div className="flex flex-wrap gap-1.5">
          {MODES.map((m) => (
            <button
              key={m.key}
              onClick={() => {
                if (m.key === "observe" && mode !== "observe") {
                  setBpm(32);
                  setShowTorso(false);
                  setTravel(0);
                }
                setMode(m.key);
              }}
              className={
                "px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors " +
                (mode === m.key
                  ? "bg-sky-500 border-sky-400 text-slate-950"
                  : "border-slate-700 bg-slate-800/60 text-slate-300 hover:bg-slate-700")
              }
            >
              {m.label}
            </button>
          ))}
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <StylePicker
            label={isPair ? "Guideur (corps A)" : "Style A (gauche)"}
            value={styleA}
            onChange={setStyleA}
          />
          <StylePicker
            label={
              isPair ? "Suiveur (corps B)" : isCompare ? "Style B (droite)" : "Style B (inactif)"
            }
            value={styleB}
            onChange={setStyleB}
          />
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
          <button
            onClick={() => setPlaying(!playing)}
            className={
              "px-3.5 py-1.5 rounded-lg text-sm font-medium border transition-colors " +
              (playing
                ? "bg-emerald-500 border-emerald-400 text-slate-950"
                : "bg-slate-800 border-slate-600 text-slate-200 hover:bg-slate-700")
            }
          >
            {playing ? "⏸ Pause" : "▶ Lecture"}
          </button>
          <label className="flex items-center gap-2 text-xs text-slate-400">
            Déplacement
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={travel}
              onChange={(e) => setTravel(Number(e.target.value))}
              className="accent-sky-400"
            />
            <span className="text-slate-200 font-mono w-16">
              {travel < 0.03 ? "sur place" : "±" + Math.round(travel * (HIP_WIDTH / 2) * 100) + " cm"}
            </span>
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-400">
            Tempo
            <input
              type="range"
              min="24"
              max="140"
              step="1"
              value={bpm}
              onChange={(e) => setBpm(Number(e.target.value))}
              className="accent-sky-400"
            />
            <span className="text-slate-200 font-mono w-14">{bpm} bpm</span>
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-400">
            Amplitude
            <input
              type="range"
              min="0.5"
              max="2"
              step="0.05"
              value={amp}
              onChange={(e) => setAmp(Number(e.target.value))}
              className="accent-amber-400"
            />
            <span className="text-slate-200 font-mono w-12">{Math.round(amp * 100)}%</span>
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-400">
            <input
              type="checkbox"
              checked={showTorso}
              onChange={(e) => setShowTorso(e.target.checked)}
              className="accent-sky-400"
            />
            Buste stylisé
          </label>
          {isPair && (
            <label className="flex items-center gap-2 text-xs text-slate-400">
              Retard du suiveur
              <input
                type="range"
                min="0"
                max="2"
                step="0.1"
                value={followDelay}
                onChange={(e) => setFollowDelay(Number(e.target.value))}
                className="accent-emerald-400"
              />
              <span className="text-slate-200 font-mono w-10">{followDelay.toFixed(1)} t</span>
            </label>
          )}
          {isPair && (
            <label className="flex items-center gap-2 text-xs text-slate-400">
              <input
                type="checkbox"
                checked={showContacts}
                onChange={(e) => setShowContacts(e.target.checked)}
                className="accent-emerald-400"
              />
              Points de contact
            </label>
          )}
          {(isCompare || isPair) && (
            <label className="flex items-center gap-2 text-xs text-slate-400">
              Isolation
              <select
                value={ghostSel}
                onChange={(e) => setGhostSel(e.target.value)}
                className="bg-slate-800 border border-slate-600 rounded-md px-2 py-1 text-xs text-slate-200"
              >
                <option value="none">Les deux corps</option>
                <option value="A">
                  {isPair ? "Guideur seul (B transparent)" : "Corps A seul (B transparent)"}
                </option>
                <option value="B">
                  {isPair ? "Suiveur seul (A transparent)" : "Corps B seul (A transparent)"}
                </option>
              </select>
            </label>
          )}
        </div>
      </div>

      <div
        className="relative rounded-2xl overflow-hidden border border-slate-800"
        style={{ height: 540 }}
      >
        <Canvas camera={{ position: [0, 1.2, 3.4], fov: 42 }} dpr={[1, 2]}>
          <color attach="background" args={["#0b1220"]} />
          <ambientLight intensity={0.65} />
          <directionalLight position={[3, 5, 4]} intensity={1.3} />
          <directionalLight position={[-3, 2, -3]} intensity={0.4} color="#93c5fd" />
          <GridFloor />
          <React.Suspense fallback={null}>
            <Rig
              styleKey={styleA}
              bpm={bpm}
              amp={amp}
              playing={playing}
              offset={offsetA}
              rotationY={isPair ? Math.PI / 2 : 0}
              ghost={ghostA}
              embrace={isPair}
              pair={isPair ? pairRef : null}
              side={isPair ? "leader" : null}
              showContacts={isPair && showContacts}
              travel={travel}
              showTorso={showTorso}
            />
            {(isCompare || isPair) && (
              <Rig
                styleKey={styleB}
                bpm={bpm}
                amp={amp}
                playing={playing}
                offset={offsetB}
                rotationY={isPair ? -Math.PI / 2 : 0}
                ghost={ghostB}
                embrace={isPair}
                phaseOffset={isPair ? followDelay : 0}
                pair={isPair ? pairRef : null}
                side={isPair ? "follower" : null}
                showContacts={isPair && showContacts}
                travel={travel}
                showTorso={showTorso}
              />
            )}
            {isPair && <ContactViz pair={pairRef} />}
          </React.Suspense>
          <OrbitControls
            target={[0, 0.88, 0]}
            enableDamping
            dampingFactor={0.08}
            minDistance={1.8}
            maxDistance={7}
          />
        </Canvas>
        <div className="absolute bottom-3 left-3 flex gap-2 pointer-events-none">
          <span
            className="px-2 py-0.5 rounded-md text-[11px] font-semibold text-slate-950"
            style={{ background: STYLES[styleA].color }}
          >
            {isPair ? "Guideur · " : ""}
            {STYLES[styleA].label}
          </span>
        </div>
        {(isCompare || isPair) && (
          <div className="absolute bottom-3 right-3 pointer-events-none">
            <span
              className="px-2 py-0.5 rounded-md text-[11px] font-semibold text-slate-950"
              style={{ background: STYLES[styleB].color }}
            >
              {isPair ? "Suiveur · " : ""}
              {STYLES[styleB].label}
            </span>
          </div>
        )}
        <div className="absolute top-3 right-3 text-[10px] text-slate-500 pointer-events-none">
          glisser pour orbiter, molette pour zoomer
        </div>
      </div>

      <div className={"grid gap-4 " + (isPair ? "md:grid-cols-3" : isCompare ? "md:grid-cols-2" : "")}>
        <InfoCard styleKey={styleA} position={isPair ? "guideur" : isCompare ? "gauche" : ""} />
        {(isCompare || isPair) && (
          <InfoCard styleKey={styleB} position={isPair ? "suiveur" : "droite"} />
        )}
        {isPair && (
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span className="font-semibold">Points de contact & emboîtement</span>
            </div>
            <ul className="space-y-1.5">
              <li className="text-xs text-slate-300 leading-relaxed flex gap-2">
                <span className="text-emerald-400">▸</span>
                <span>Buste : connexion de guidage (kizomba, suave)</span>
              </li>
              <li className="text-xs text-slate-300 leading-relaxed flex gap-2">
                <span className="text-emerald-400">▸</span>
                <span>Bassin/hanches : tarraxinha, kompa en balancier</span>
              </li>
              <li className="text-xs text-slate-300 leading-relaxed flex gap-2">
                <span className="text-emerald-400">▸</span>
                <span>Bras : le cadre se referme en face à face (emboîtement)</span>
              </li>
              <li className="text-xs text-slate-300 leading-relaxed flex gap-2">
                <span className="text-emerald-400">▸</span>
                <span>
                  Vert = contact établi, rouge = rupture. Faites varier le retard du suiveur pour
                  voir le cadre respirer et chercher le décalage où les orbites des bassins
                  s'imbriquent.
                </span>
              </li>
            </ul>
          </div>
        )}
      </div>

      <p className="text-[11px] text-slate-500 leading-relaxed">
        Anatomie réelle du bassin au pied : os coxaux, sacrum, fémurs, patellas, tibias, fibulas et
        les 52 os des pieds, d'après BodyParts3D (réduction polygonale 99 %), © The Database Center
        for Life Science (DBCLS), licence CC BY-SA 2.1 Japan. Buste stylisé en transparence au-dessus
        du sacrum. « Déplacement » : 0 = sur place, 100 % = largeur de hanche (±17 cm). Phase 3 :
        migration en projet Vite + three.js déployable (GitHub Pages/Vercel). Spec biomécanique
        sauvegardée en Knowledge.
      </p>
    </div>
  );
}
